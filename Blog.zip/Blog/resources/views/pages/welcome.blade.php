@extends('main')

@section('title', '| Home')

@section('navibar1')
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="#me">Me</a>
      </div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav navbar-right">
          <li><a href="#work">WORK</a></li>
          <li><a href="#services">SKILLS</a></li>
          <li><a href="#about">ABOUT ME</a></li>
          <li><a href="#contact">CONTACT ME</a></li>
          <li><a href="blog">BLOG</a></li>
        </ul>
      </div>
    </div>
@endsection


@section('mainsection')
<!-- First Container -->
  <div class="container-fluid bg-1 text-center" id="me">
    <h3 class="margin">Who Am I?</h3>
    <h3>I'm a Software Developer</h3><br>&<br>
    <h4> a Passion Photographer </h4>
  </div>


  <img src="public/Space-Minimal-Background-HD-Wallpaper.jpg" alt="myimage">

  <div class="container-fluid bg-grey" id="work">
    <div class="row">
      <div class="col-sm-4">
        <span class="glyphicon glyphicon-globe logo slideanim"></span>
      </div>
      <div class="col-sm-8">
        <h2>Work</h2><br>
        <h4><strong>SLT Vehicle management system</strong> build with my team members as a C# windows form application assigment in the university. We were able to develop a good transport management system for Sri Lanka Telecom & they were happy with our final product btw we were not permissioned to sell our product.</h4><br>
        <h4><strong>Store management system</strong> will finalized asap.</h4>
      </div>
    </div>
  </div>

<!-- Container (skill Section) -->
  <div id="services" class="container-fluid text-center">
    <h2>Skills</h2>
    <h4>What I offer</h4>
    <br>
    <div class="row slideanim">
      <div class="col-sm-4">
        <span class="glyphicon glyphicon-off logo-small"></span>
        <h4>Programming and Coding</h4>
        <p>HTML, CSS, PHP Laravel, Java, C#, C</p>
      </div>
    <div class="col-sm-4">
        <span class="glyphicon glyphicon-heart logo-small"></span>
        <h4>Software Development</h4>
        <p>Windows & Android app development.</p>
      </div>
      <div class="col-sm-4">
        <span class="glyphicon glyphicon-lock logo-small"></span>
        <h4>Communication ability</h4>
        <p></p>
      </div>
    </div>
    <br><br>
    <div class="row slideanim">
      <div class="col-sm-4">
        <span class="glyphicon glyphicon-leaf logo-small"></span>
        <h4>Problem solving & Documentation habits</h4>
        <p></p>
      </div>
      <div class="col-sm-4">
        <span class="glyphicon glyphicon-certificate logo-small"></span>
        <h4>Teamwork & Leadership</h4>
        <p></p>
      </div>
      <div class="col-sm-4">
        <span class="glyphicon glyphicon-wrench logo-small"></span>
        <h4>Hardware knowledge & Overall project management</h4>
        <p></p>
      </div>
    </div>
  </div>

<!-- Container (About Section) -->
  <div id="about" class="container-fluid">
    <div class="row">
      <div class="col-sm-8">
        <h2>About Me</h2><br>
        <h4> I am an undergraduate software engineer from Sri Lanka who loves to write software to build great products and help businesses succeed with their goals.</h4>
        <br><button class="btn btn-default btn-lg">Get in Touch</button>
      </div>
      <div class="col-sm-4">
        <span class="glyphicon glyphicon-signal logo"></span>
      </div>
    </div>
  </div>

<!-- Container (Contact Section) -->
  <div id="contact" class="container-fluid bg-grey">
    <h2 class="text-center">CONTACT me</h2>
    <div class="row">
      <div class="col-sm-5">
        <p>Contact me and i'll get back to you within 24 hours.</p>
        <p><span class="glyphicon glyphicon-map-marker"></span> Gampaha, Sri Lanka</p>
        <p><span class="glyphicon glyphicon-phone"></span> +94 779574527 </p>
        <p><span class="glyphicon glyphicon-envelope"></span> gayashanekanayaka1@gmail.com</p>
      </div>
      <div class="col-sm-7 slideanim">
        <div class="row">
          <div class="col-sm-6 form-group">
            <input class="form-control" id="name" name="name" placeholder="Name" type="text" required>
          </div>
          <div class="col-sm-6 form-group">
            <input class="form-control" id="email" name="email" placeholder="Email" type="email" required>
          </div>
        </div>
          <textarea class="form-control" id="comments" name="comments" placeholder="Comment" rows="5"></textarea><br>
        <div class="row">
          <div class="col-sm-12 form-group">
            <button class="btn btn-default pull-right" type="submit">Send</button>
          </div>
        </div>
      </div>
    </div>
  </div>

<!-- Container (blog Section) -->
  <div id="portfolio" class="container-fluid text-center bg-grey">
    <h2>Blog</h2><br>
    <h4>Recent Posts</h4>
    <div class="row text-center slideanim">
      <div class="col-sm-4">
        <div class="thumbnail">
          <img src="paris.jpg" alt="Paris" width="400" height="300">
          <p><strong>Paris</strong></p>
          <p>Yes, we built Paris</p>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="thumbnail">
          <img src="newyork.jpg" alt="New York" width="400" height="300">
          <p><strong>New York</strong></p>
          <p>We built New York</p>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="thumbnail">
          <img src="sanfran.jpg" alt="San Francisco" width="400" height="300">
          <p><strong>San Francisco</strong></p>
          <p>Yes, San Fran is ours</p>
        </div>
      </div>
  </div><br>
@endsection
