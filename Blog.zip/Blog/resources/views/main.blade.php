<!DOCTYPE html>
<html lang="en">

@include('partials._head')

<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<!-- Navbar home & blog-->
  <nav class="navbar navbar-default">
    @yield('navibar')
    @yield('navibar1')
  </nav>

<!-- home setion-->
  <div class="main">
  @yield('mainsection')
  </div>

<!--populor postblog -->
    <div class="container">
    @yield('content1')
    </div>

<!--blog-->
    <div id="portfolio" class="container-fluid text-center bg-grey">
      @yield('content2')
    </div><br>

<!--footer-->
    <footer class="container-fluid text-center">
      <a href="#myPage" title="To Top">
        <span class="glyphicon glyphicon-chevron-up"></span>
      </a>
      <p>Made by Kuncha with the help of <a href="https://www.w3schools.com" title="Visit w3schools">www.w3schools.com</a></p>
      <p>Copyright Kunchana - All Rights Reserved
    </footer>

<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {
    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 900, function(){

        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });

  $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})
</script>

</body>
</body>
</html>
